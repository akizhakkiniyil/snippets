package com.hackathon.accessguardian.mcp.client.service.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomBeanParser<T> {
    private final Class<T> type;

    public CustomBeanParser(Class<T> type) {
        this.type = type;
    }
    public T parse(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
       // T object = mapper.convertValue(json, type);
       // return object;
        return mapper.readValue(json,type);

    }
    public String getFormat() {
        return "{\"type\"" + type.getSimpleName()+ "\"}";
    }
}
