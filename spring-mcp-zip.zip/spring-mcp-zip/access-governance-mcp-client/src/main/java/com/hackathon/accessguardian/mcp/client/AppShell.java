package com.hackathon.accessguardian.mcp.client;

import com.vaadin.flow.component.page.AppShellConfigurator;
import com.vaadin.flow.component.page.Push;
import com.vaadin.flow.theme.Theme;
import com.vaadin.flow.theme.lumo.Lumo;

/**
 * This class is used to configure the global settings of your application,
 * such as the application theme.
 */
//@Theme(value = "chatbot") // Move the @Theme annotation here
@Push
@Theme(value = "gemini-theme", variant= Lumo.DARK)
public class AppShell implements AppShellConfigurator {
}
