package com.hackathon.accessguardian.mcp.client.ui;

import com.hackathon.accessguardian.mcp.client.service.AccessGovernanceClientService;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.messages.MessageInput;
import com.vaadin.flow.component.messages.MessageList;
import com.vaadin.flow.component.messages.MessageListItem;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.page.Push;
import com.vaadin.flow.component.tabs.TabSheet;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatResponse;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;


@Route("general")
@Slf4j
public class GeneralView extends VerticalLayout {

    private final MessageList messageList = new MessageList();
    private  List<MessageListItem> messages = new ArrayList<>();

    // Fields for Access Recommendation
    private TextField recEmployeeId;
    private TextField recEmployeeName;
    private TextField recDepartment;
    private TextField recRole;
    private TextField recLineManagerId;

    private final UI ui; // Reference to the current UI for thread-safe updates
    //private final AiAssistanceService aiAssistanceService;
    private final AccessGovernanceClientService clientService;

    public GeneralView( AccessGovernanceClientService clientService) {
      //  this.aiAssistanceService = aiAssistanceService;
        this.clientService = clientService;
        this.ui = UI.getCurrent();

        addClassName("gemini-view");
        setSizeFull();

        H2 title = new H2("Access Governance AI Assistant");
        Paragraph description = new Paragraph("This assistant helps with access recommendations, anomaly explanations, and policy drift analysis.");

        TabSheet tabSheet = new TabSheet();
        tabSheet.setWidthFull();

        // The message list is displayed above the tabs for a unified conversation view.
        VerticalLayout chatContainer = new VerticalLayout(messageList);
        chatContainer.setSizeFull();
        chatContainer.setFlexGrow(1, messageList);

        tabSheet.add("General Chat", createGeneralChatTab());
        tabSheet.add("Access Recommendation", createRecommendationTab());
        tabSheet.add("Access Anomaly", createAnomalyTab());
        tabSheet.add("Policy Drift", createPolicyDriftTab());

        add(title, description, chatContainer, tabSheet);
        setFlexGrow(1, chatContainer); // Make chat container grow
    }

    private Component createGeneralChatTab() {
        MessageInput messageInput = new MessageInput(e -> sendGeneralChat(e.getValue()));
        messageInput.setWidthFull();

        VerticalLayout layout = new VerticalLayout(messageInput);
        layout.setPadding(false);
        layout.setSpacing(false);
        return layout;
    }

    private Component createRecommendationTab() {
        FormLayout form = new FormLayout();
        recEmployeeId = new TextField("Employee ID (New Joiner)", "new001", "");
        recEmployeeName = new TextField("Employee Name", "John Doe", "");
        recDepartment = new TextField("Department", "Engineering", "");
        recRole = new TextField("Role", "Software Engineer", "");
        recLineManagerId = new TextField("Line Manager ID", "mgr001", "");
        form.add(recEmployeeId, recEmployeeName, recDepartment, recRole, recLineManagerId);

        Button sendButton = new Button("Get Recommendation", event -> sendRecommendation());

        VerticalLayout layout = new VerticalLayout(form, sendButton);
        layout.setPadding(false);
        return layout;
    }

    private Component createAnomalyTab() {
        TextField anomalyEmployeeId = new TextField("Employee ID", "emp001");
        anomalyEmployeeId.setWidthFull();
        Button sendButton = new Button("Explain Anomaly", event -> sendAnomalyExplanation(anomalyEmployeeId.getValue()));

        VerticalLayout layout = new VerticalLayout(anomalyEmployeeId, sendButton);
        layout.setPadding(false);
        return layout;
    }

    private Component createPolicyDriftTab() {
        FormLayout form = new FormLayout();
        TextField driftGroupId = new TextField("Group ID", "grp001");
        TextField driftBaselineDate = new TextField("Baseline Date (YYYY-MM-DD)", "2024-01-01");
        form.add(driftGroupId, driftBaselineDate);

        Button sendButton = new Button("Explain Policy Drift", event -> sendPolicyDriftExplanation(driftGroupId.getValue(), driftBaselineDate.getValue()));

        VerticalLayout layout = new VerticalLayout(form, sendButton);
        layout.setPadding(false);
        return layout;
    }

    private void sendRecommendation() {
        final String employeeId = recEmployeeId.getValue();
        final String employeeName = recEmployeeName.getValue();
        final String department = recDepartment.getValue();
        final String role = recRole.getValue();
        final String lineManagerId = recLineManagerId.getValue();

        if (employeeId.isBlank() || employeeName.isBlank() || department.isBlank() || role.isBlank() || lineManagerId.isBlank()) {
            Notification.show("Please fill in all recommendation fields.");
            return;
        }

        String userMessageText = "Get access recommendation for employee: " + employeeId;
        executeChatAction(userMessageText, () -> clientService.recommendAccess(employeeId, employeeName, department, role, lineManagerId));
    }

    private void sendAnomalyExplanation(String employeeId) {
        if (employeeId.isBlank()) {
            Notification.show("Employee ID is required for anomaly explanation.");
            return;
        }
        String userMessageText = "Explain access anomaly for employee: " + employeeId;
        executeChatAction(userMessageText, () -> clientService.explainAnomaly(employeeId));
    }

    private void sendPolicyDriftExplanation(String groupId, String baselineDateStr) {
        if (groupId.isBlank() || baselineDateStr.isBlank()) {
            Notification.show("Please enter Group ID and Baseline Date.");
            return;
        }

        final LocalDate baselineDate;
        try {
            baselineDate = LocalDate.parse(baselineDateStr);
        } catch (DateTimeParseException e) {
            Notification.show("Invalid date format. Please use YYYY-MM-DD.");
            return;
        }

        String userMessageText = "Explain policy drift for group: " + groupId + " since " + baselineDateStr;
        executeChatAction(userMessageText, () -> clientService.explainPolicyDrift(groupId, baselineDate));
    }

    private void sendGeneralChat(String userMessageText) {
        if (userMessageText == null || userMessageText.isBlank()) {
            return;
        }
        executeChatAction(userMessageText, () -> clientService.generalChat(userMessageText));
    }

    /**
     * Handles the asynchronous execution of a chat action, including showing a loading indicator.
     * This version uses an immutable update strategy and adds a crucial call to scrollToEnd()
     * to ensure the new message is visible.
     *
     * @param userMessageText The text from the user to display in the chat.
     * @param serviceCall     A supplier that executes the backend AI service call.
     */
    private void executeChatAction(String userMessageText, Supplier<ChatResponse> serviceCall) {
        // Add the user's message to the chat
        MessageListItem userMessage = new MessageListItem(userMessageText, Instant.now(), "You");
        userMessage.setUserColorIndex(1); // Blue for user
        this.messages.add(userMessage);

        // Add a temporary "Thinking..." message from the bot
        MessageListItem loadingMessage = new MessageListItem("Thinking...", Instant.now(), "AI");
        loadingMessage.setUserColorIndex(2); // Gray for bot
        this.messages.add(loadingMessage);

        // Update the UI immediately to show the user message and loading indicator
        messageList.setItems(new ArrayList<>(this.messages));
        // Scroll to show the "Thinking..." message by executing JavaScript on the element
        messageList.getElement().executeJs("this.scrollTop = this.scrollHeight");

        // Execute the service call in a background thread
        CompletableFuture.supplyAsync(serviceCall)
                .whenComplete((chatResponse, throwable) -> {
                    // When the future completes, update the UI from the main UI thread
                    ui.access(() -> {
                        log.info("Entering ui.access block to update the chat UI.");

                        MessageListItem finalBotMessage;

                        if (throwable != null) {
                            // Case 1: The service call itself threw an exception.
                            log.error("Error during asynchronous service call:", throwable);
                            String errorMessage = "Sorry, an error occurred: " + throwable.getMessage();
                            finalBotMessage = new MessageListItem(errorMessage, Instant.now(), "AI");
                            finalBotMessage.setUserColorIndex(3); // Red for error
                            Notification.show("Error processing request.", 3000, Notification.Position.MIDDLE);
                        } else {
                            // Case 2: The service call succeeded.
                            try {
                                String botResponseText;
                                if (chatResponse != null && chatResponse.getResult() != null && chatResponse.getResult().getOutput() != null) {
                                    botResponseText = chatResponse.getResult().getOutput().getText();                                    // Check if the response is a JSON string
                                    System.out.println("GeneralView.executeChatAction:botResponseText:" + botResponseText);
                                    if (botResponseText.trim().startsWith("{") && botResponseText.trim().endsWith("}")) {
                                        try {
                                            // Attempt to pretty print JSON
                                            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
                                            Object json = mapper.readValue(botResponseText, Object.class);
                                            botResponseText = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
                                            log.info("Successfully pretty-printed JSON response.botResponseText:" + botResponseText);
                                        } catch (com.fasterxml.jackson.core.JsonProcessingException jsonEx) {
                                            log.warn("Response looks like JSON but could not be parsed: {}", jsonEx.getMessage());
                                            // If it fails, just use the original text
                                        }
                                    }
                                    log.info("Successfully extracted bot response text.");
                                } else {
                                    botResponseText = "Sorry, I received an empty or invalid response from the service.";
                                    log.warn("ChatResponse or its nested properties were null. Response: {}", chatResponse);
                                }
                                finalBotMessage = new MessageListItem(botResponseText, Instant.now(), "AI");
                                finalBotMessage.setUserColorIndex(2); // Gray for bot
                            } catch (Exception e) {
                                log.error("Failed to process the successful chat response.", e);
                                finalBotMessage = new MessageListItem("Sorry, an error occurred while processing the response.", Instant.now(), "AI");
                                finalBotMessage.setUserColorIndex(3); // Red for error
                            }
                        }

                        // --- Immutable UI Update Logic ---
                        // 1. Create a new list that will represent the final state.
                        List<MessageListItem> newMessages = new ArrayList<>();

                        // 2. Copy all previous messages EXCEPT the loading message into the new list.
                        for (MessageListItem message : this.messages) {
                            if (message != loadingMessage) { // Use reference equality to find the exact loading message
                                newMessages.add(message);
                            }
                        }

                        // 3. Add the final response (or error) message to the new list.
                        newMessages.add(finalBotMessage);

                        // 4. Atomically update the view's state to point to the NEW list instance.
                        this.messages = newMessages;

                        // 5. Update the UI component with the new list instance.
                        log.info("Updating message list in UI with a new list instance. Final message count: {}", this.messages.size());
                        messageList.setItems(this.messages);

                        // 6. *** CRUCIAL STEP ***
                        //    After updating the items, scroll to the end to make the new message visible.
                        //    This is done by executing JavaScript on the component's DOM element.
                        messageList.getElement().executeJs("this.scrollTop = this.scrollHeight");
                        log.info("Executed JS to scroll to the end of the message list.");
                    });
                });
    }
}