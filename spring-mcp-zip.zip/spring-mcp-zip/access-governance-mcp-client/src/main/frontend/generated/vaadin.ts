import './vaadin-featureflags.js';

import './index';

import './vaadin-react.js';
import './theme-gemini-theme.global.generated.js';
import { applyTheme } from './theme.js';
applyTheme(document);
