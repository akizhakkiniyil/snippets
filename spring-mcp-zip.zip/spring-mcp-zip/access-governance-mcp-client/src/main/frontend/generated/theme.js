import {applyTheme as _applyTheme} from './theme-gemini-theme.generated.js';
export const applyTheme = _applyTheme;
