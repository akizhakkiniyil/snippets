// When this file is imported, global styles are automatically applied

import '@vaadin/vaadin-lumo-styles/typography-global.js';
import '@vaadin/vaadin-lumo-styles/color-global.js';
import '@vaadin/vaadin-lumo-styles/badge-global.js';
import '@vaadin/vaadin-lumo-styles/utility-global.js';
import 'themes/gemini-theme/styles.css';

