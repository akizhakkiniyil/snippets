package com.hackathon.accessguardian.mcp.server.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(toBuilder = true)
public class GroupMembership {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key for this entity
    @NonNull
    private String userGuid;
    @NonNull
    private String groupId;
    private LocalDate assignedDate;
    private LocalDate revokedDate; // Null if still active
    private String assignedBy; // e.g., "HR", "IT", "Self-service"
}
