package com.hackathon.accessguardian.mcp.server.service;


import com.hackathon.accessguardian.mcp.server.domain.*;
import com.hackathon.accessguardian.mcp.server.repository.*;
import com.hackathon.accessguardian.mcp.server.service.model.AccessReviewSummary;
import com.hackathon.accessguardian.mcp.server.service.model.EmployeeContextGraph;
import com.hackathon.accessguardian.mcp.server.service.model.PolicyDriftReport;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


import org.springframework.ai.tool.annotation.Tool;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import java.util.Arrays;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccessGovernanceService {

    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final GroupMembershipRepository groupMembershipRepository;
    private final AccessChangeLogRepository accessChangeLogRepository;
    private final AccessAnomalyRepository accessAnomalyRepository;

    // --- Basic Data Retrieval Tools ---

    @Tool(name = "Get_Employee_Details", description = "Retrieve full details for an employee by their employee ID. Input: employeeId (String).")
    public Employee getEmployeeDetails(String userGuid) {
        log.info("Retrieving details for employee: {}", userGuid);
        Employee retVal = employeeRepository.findByUserGuid(userGuid).orElse(null);
        System.out.println("AccessGovernanceService.getEmployeeDetails:" + retVal);
        return retVal;
    }

    @Tool(name = "Get_Employee_Details_by_Name", description = "Retrieve full details for an employee by their name. Returns a list of employees if multiple match. Input: name (String).")
    public List<Employee> getEmployeeDetailsByName(String name) {
        log.info("Retrieving details for employee by name: {}", name);
        List<Employee> retVal = employeeRepository.findByName(name).map(List::of).orElse(List.of());
        System.out.println("AccessGovernanceService.getEmployeeDetailsByName:" + retVal);
        return retVal; // Assuming name is unique enough for single result or return empty list
    }

    @Tool(name = "Get_Direct_Reports", description = "Get a list of direct reports for a given line manager's employee ID. Input: lineManagerId (String).")
    public List<Employee> getDirectReports(String lineManagerId) {
        log.info("Retrieving direct reports for manager: {}", lineManagerId);
        List<Employee> retVal = employeeRepository.findByLineManagerId(lineManagerId);
        System.out.println("AccessGovernanceService.getDirectReports:" + retVal);
        return retVal;
    }

    @Tool(name = "Get_Department_Employees", description = "Get a list of all employees in a specific department. Input: department (String).")
    public List<Employee> getDepartmentEmployees(String department) {
        log.info("Retrieving employees in department: {}", department);
        List<Employee> retVal = employeeRepository.findByDepartment(department);
        System.out.println("AccessGovernanceService.getDepartmentEmployees:" + retVal);
        return retVal;
    }

    @Tool(name = "Get_Employee_Group_Memberships", description = "Get all active group memberships for a specific employee by their employee ID. Input: employeeId (String).")
    public List<GroupMembership> getEmployeeGroupMemberships(String userGuid) {
        log.info("Retrieving group memberships for employee: {}", userGuid);
        List<GroupMembership> retVal = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid);
        System.out.println("AccessGovernanceService.getEmployeeGroupMemberships:" + retVal);
        return retVal;
    }

    @Tool(name = "Get_Group_Members", description = "Get a list of all employee IDs who are members of a specific group. Input: groupId (String).")
    public List<String> getGroupMembers(String groupId) {
        log.info("Retrieving members for group: {}", groupId);
        List<String> retVal = groupMembershipRepository.findByGroupId(groupId).stream()
                .map(GroupMembership::getUserGuid)
                .collect(Collectors.toList());
        System.out.println("AccessGovernanceService.getGroupMembers:" + retVal);
        return retVal;
    }

    @Tool(name = "Get_Group_Details", description = "Retrieve details for a specific access group by its group ID. Input: groupId (String).")
    public Groupee getGroupDetails(String groupId) {
        log.info("Retrieving details for group: {}", groupId);
        Groupee retVal = groupRepository.findByGroupId(groupId).orElse(null);
        return retVal;
    }

    @Tool(name = "Get_Historical_Access_Changes", description = "Retrieve historical access changes (assignments/revocations) for an employee within a date range. Input: employeeId (String), startDate (YYYY-MM-DD), endDate (YYYY-MM-DD).")
    public List<AccessChangeLog> getHistoricalAccessChanges(String userGuid, LocalDate startDate, LocalDate endDate) {
        log.info("Retrieving historical access changes for employee {} between {} and {}", userGuid, startDate, endDate);
        List<AccessChangeLog> retVal = accessChangeLogRepository.findByUserGuidAndChangeDateBetween(userGuid, startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
        System.out.println("AccessGovernanceService.getHistoricalAccessChanges:" + retVal);
        return retVal;
    }

    // --- Tools for "Tree-of-Thoughts" structured output / Analytical Support ---

    @Tool(name = "Get_Employee_Context_Graph",
            description = "Retrieves a comprehensive context graph for an employee, including their details, line manager, direct reports, peers in the same department/role, and their current group memberships. This is designed for complex analytical tasks. Input: employeeId (String).")
    public EmployeeContextGraph getEmployeeContextGraph(String userGuid) {
        log.info("Generating context graph for employee: {}", userGuid);
        Optional<Employee> employeeOpt = employeeRepository.findByUserGuid(userGuid);
        if (employeeOpt.isEmpty()) {
            return null;
        }
        Employee employee = employeeOpt.get();

        // Populate line manager name
        if (employee.getLineManagerId()!= null) {
            employeeRepository.findByUserGuid(employee.getLineManagerId())
                    .ifPresent(manager -> employee.setLineManagerName(manager.getName()));
        }

        List<Employee> directReports = employeeRepository.findByLineManagerId(userGuid);
        List<Employee> peers = employeeRepository.findByDepartment(employee.getDepartment()).stream()
                .filter(e ->!e.getUserGuid().equals(userGuid) && e.getRole().equals(employee.getRole()))
                .collect(Collectors.toList());

        List<GroupMembership> currentMemberships = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid);

        // For direct reports and peers, also fetch their current group memberships for richer context
        directReports.forEach(dr -> dr.setCurrentGroupMemberships(groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(dr.getUserGuid())));
        peers.forEach(p -> p.setCurrentGroupMemberships(groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(p.getUserGuid())));

        EmployeeContextGraph retVal = new EmployeeContextGraph(
                employee,
                employee.getLineManagerId() != null ? employeeRepository.findByUserGuid(employee.getLineManagerId()).orElse(null) : null,
                directReports,
                peers,
                currentMemberships
        );
        System.out.println("AccessGovernanceService.getEmployeeContextGraph:" + retVal);
        return retVal;
    }

    @Tool(name = "Get_Peer_Group_Memberships_by_Role_and_Department",
            description = "Retrieves active group memberships for employees who share the same role and department as a specified employee. Useful for peer-based access analysis. Input: employeeId (String).")
    public List<GroupMembership> getPeerGroupMembershipsByRoleAndDepartment(String userGuid) {
        log.info("Retrieving peer group memberships for employee: {}", userGuid);
        Optional<Employee> employeeOpt = employeeRepository.findByUserGuid(userGuid);
        if (employeeOpt.isEmpty()) {
            return List.of();
        }
        Employee employee = employeeOpt.get();

        List<Employee> peers = employeeRepository.findByDepartment(employee.getDepartment()).stream()
                .filter(e ->!e.getUserGuid().equals(userGuid) && e.getRole().equals(employee.getRole()))
                .collect(Collectors.toList());

        List<GroupMembership> peerMemberships = new ArrayList<>();
        for (Employee peer : peers) {
            peerMemberships.addAll(groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(peer.getUserGuid()));
        }
        System.out.println("AccessGovernanceService.getPeerGroupMembershipsByRoleAndDepartment:" + peerMemberships);
        return peerMemberships;
    }

    @Tool(name = "Detect_Access_Anomalies",
            description = "Flags employees with unusual access patterns for their role/team based on historical data and peer comparisons. Returns a list of detected anomalies. Input: employeeId (String).")
    public List<AccessAnomaly> detectAccessAnomalies(String userGuid) {
        log.info("Detecting access anomalies for employee: {}", userGuid);
        // In a real system, this would trigger an ML model (e.g., Isolation Forest, Autoencoder)
        // For this example, we'll return some dummy anomalies if the employee exists.
        Optional<Employee> byUserGuid = employeeRepository.findByUserGuid(userGuid);
        if (byUserGuid.isPresent()) {
            List<AccessAnomaly> anomalies = new ArrayList<>();
            // Example dummy anomaly: if employee has "Admin" role but no "Admin" group
            if (byUserGuid.isPresent() && byUserGuid.get().getRole().contains("Admin")) {
                List<GroupMembership> currentGroups = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid);
                boolean hasAdminGroup = currentGroups.stream().anyMatch(gm -> groupRepository.findById(gm.getGroupId()).map(Groupee::getGroupName).orElse("").contains("Admin"));
                if (!hasAdminGroup) {
                    anomalies.add(new AccessAnomaly(null, userGuid, "Missing_Admin_Group_for_Admin_Role",
                            "Employee with Admin role does not have a corresponding Admin group membership.",
                            LocalDateTime.now(), 0.8, "Detected"));
                }
            }
            // Example dummy anomaly: too many groups compared to peers
            List<GroupMembership> employeeGroups = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid);
            List<GroupMembership> peerGroups = getPeerGroupMembershipsByRoleAndDepartment(userGuid);
            long distinctPeerGroups = peerGroups.stream().map(GroupMembership::getGroupId).distinct().count();
            if (employeeGroups.size() > (distinctPeerGroups / 2) + 5) { // Arbitrary threshold
                anomalies.add(new AccessAnomaly(null, userGuid, "Excessive_Group_Memberships",
                        "Employee has significantly more group memberships than typical peers in the same role/department.",
                        LocalDateTime.now(), 0.7, "Detected"));
            }
            return anomalies;
        }
        return List.of();
    }

    @Tool(name = "Generate_Access_Review_Summary",
            description = "Generates a summary for a manager during access audits, highlighting discrepancies in access compared to peers. Input: employeeId (String).")
    public AccessReviewSummary generateAccessReviewSummary(String userGuid) {
        log.info("Generating access review summary for employee: {}", userGuid);
        Optional<Employee> employeeOpt = employeeRepository.findByUserGuid(userGuid);
        if (employeeOpt.isEmpty()) {
            return null;
        }
        Employee employee = employeeOpt.get();

        List<GroupMembership> employeeMemberships = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid);
        System.out.println("AccessGovernanceService.generateAccessReviewSummary:" + employeeMemberships);
        
        List<GroupMembership> peerMemberships = getPeerGroupMembershipsByRoleAndDepartment(userGuid);
        System.out.println("AccessGovernanceService.generateAccessReviewSummary:" + peerMemberships);

        Map<String, Long> peerGroupCounts = peerMemberships.stream()
                .collect(Collectors.groupingBy(GroupMembership::getGroupId, Collectors.counting()));

        List<AccessReviewSummary.GroupDiscrepancy> discrepancies = new ArrayList<>();
        for (GroupMembership empMembership : employeeMemberships) {
            long count = peerGroupCounts.getOrDefault(empMembership.getGroupId(), 0L);
            if (count == 0) {
                groupRepository.findByGroupId(empMembership.getGroupId()).ifPresent(groupee ->
                        discrepancies.add(new AccessReviewSummary.GroupDiscrepancy(
                                groupee.getGroupName(),
                                "Employee has access, but no peers in same role/department do.",
                                "Excessive"
                        ))
                );
            } else {
                // Example: if less than 5% of peers have it, flag as unusual
                long totalPeers = employeeRepository.findByDepartment(employee.getDepartment()).stream()
                        .filter(e -> e.getRole().equals(employee.getRole())).count();
                if (totalPeers > 0 && (double) count / totalPeers < 0.05) {
                    groupRepository.findByGroupId(empMembership.getGroupId()).ifPresent(groupee ->
                            discrepancies.add(new AccessReviewSummary.GroupDiscrepancy(
                                    groupee.getGroupName(),
                                    String.format("Employee has access, but only %d%% of peers in this role/department do.", (int) ((double) count / totalPeers * 100)),
                                    "Unusual"
                            ))
                    );
                }
            }
        }

        return new AccessReviewSummary(employee.getName(), employee.getRole(), employee.getDepartment(), discrepancies);
    }

    @Tool(name = "Detect_Policy_Drift",
            description = "Detects if group memberships for a specific group have drifted over time compared to a baseline. Returns a report of added and removed members. Input: groupId (String), baselineDate (YYYY-MM-DD).")
    public PolicyDriftReport detectPolicyDrift(String groupId, LocalDate baselineDate) {
        log.info("Detecting policy drift for group {} since baseline {}", groupId, baselineDate);
        Groupee groupee = groupRepository.findByGroupId(groupId).orElse(null);
         if (groupee == null) {
            System.out.println("AccessGovernanceService.detectPolicyDrift:group is empty:");
            return null;
        } else {
            System.out.println("AccessGovernanceService.detectPolicyDrift:group is not empty:" + groupee);
        }
        System.out.println("AccessGovernanceService.detectPolicyDrift:groupee:" + groupee);
        List<GroupMembership> currentMemberships = groupMembershipRepository.findByGroupId(groupId).stream()
                .filter(gm -> gm.getRevokedDate() == null || gm.getRevokedDate().isAfter(LocalDate.now()))
                .collect(Collectors.toList());
        System.out.println("AccessGovernanceService.detectPolicyDrift:currentMemberships:" + currentMemberships);
        List<GroupMembership> baselineMemberships = groupMembershipRepository.findByGroupId(groupId).stream()
                .filter(gm -> gm.getAssignedDate().isBefore(baselineDate) && (gm.getRevokedDate() == null || gm.getRevokedDate().isAfter(baselineDate)))
              .collect(Collectors.toList());
        System.out.println("AccessGovernanceService.detectPolicyDrift:baselineMemberships" + baselineMemberships);

        List<String> addedMembers = currentMemberships.stream()
                .filter(cm -> baselineMemberships.stream().noneMatch(bm -> bm.getUserGuid().equals(cm.getUserGuid())))
                .map(GroupMembership::getUserGuid)
                .collect(Collectors.toList());
        System.out.println("AccessGovernanceService.detectPolicyDrift:addedMembers" + addedMembers);

        List<String> removedMembers = baselineMemberships.stream()
                .filter(bm -> currentMemberships.stream().noneMatch(cm -> cm.getUserGuid().equals(bm.getUserGuid())))
                .map(GroupMembership::getUserGuid)
                .collect(Collectors.toList());
        System.out.println("AccessGovernanceService.detectPolicyDrift:removedMembers" + removedMembers);

        return new PolicyDriftReport(groupee.getGroupName(), baselineDate, addedMembers, removedMembers);
    }

    // Helper method to simulate initial data for H2
    public void initializeData() {
        // Employees

        Employee emp1 = new Employee(1L,"emp_001","001", "Alice Johnson", "Engineering", "Software Engineer", LocalDate.of(2022, 1, 15), "mgr_001",true,null,null,null);
        Employee emp2 = new Employee(2L,"emp_002", "002","Bob Williams", "Engineering", "Software Engineer", LocalDate.of(2022, 3, 10), "mgr_001", true,null, null,null);
        Employee emp3 = new Employee(3L,"emp_003","003", "Charlie Brown", "Marketing", "Marketing Specialist", LocalDate.of(2023, 2, 1), "mgr_002", true,null, null,null);
        Employee emp4 = new Employee(4L,"emp_004","004", "Diana Prince", "Marketing", "Marketing Specialist", LocalDate.of(2023, 5, 20), "mgr_002",false, null, null,null);
        Employee emp5 = new Employee(5L,"emp_005","005", "Eve Adams", "HR", "HR Generalist", LocalDate.of(2021, 8, 1), "mgr_003", true,null, null,null);
        Employee mgr1 = new Employee(6L,"mgr_006", "006","Frank White", "Engineering", "Engineering Manager", LocalDate.of(2020, 1, 1), "exec001",false, null, null,null);
        Employee mgr2 = new Employee(7L,"mgr_007","007", "Grace Lee", "Marketing", "Marketing Manager", LocalDate.of(2021, 6, 1), "exec001",true, null, null,null);
        Employee mgr3 = new Employee(8L,"mgr_008", "008","Henry Green", "HR", "HR Manager", LocalDate.of(2019, 10, 1), "exec001", true,null, null,null);
        Employee exec1 = new Employee(9L,"exec_009","009", "Ivy King", "Executive", "CEO", LocalDate.of(2018, 1, 1), null, true,null, null,null);

        employeeRepository.saveAll(Arrays.asList(emp1, emp2, emp3, emp4, emp5, mgr1, mgr2, exec1));

        // Groups
        Groupee g1 = new Groupee(1L,"grp_001", "Engineering_Dev_Tools", "Access to core development tools for engineers", "Application");
        Groupee g2 = new Groupee(2L,"grp_002", "Marketing_Campaign_Access", "Access to marketing campaign management platforms", "Application");
        Groupee g3 = new Groupee(3L,"grp_003", "HR_Confidential_Data", "Access to sensitive HR employee data", "Application");
        Groupee g4 = new Groupee(4L,"grp_004", "All_Employees_VPN", "VPN access for all employees", "Network");
        Groupee g5 = new Groupee(5L,"grp_005", "Engineering_Leads", "Access for engineering managers to team dashboards", "Application");
        Groupee g6 = new Groupee(6L,"grp_006", "Marketing_Analytics", "Access to marketing analytics dashboards", "Application");
        Groupee g7 = new Groupee(7L,"grp_007", "Finance_Reporting", "Access to financial reporting systems", "Application"); // Not directly used by current employees

        groupRepository.saveAll(Arrays.asList(g1, g2, g3, g4, g5, g6, g7));

        // Group Memberships
        // Alice (emp_001) - Eng
        groupMembershipRepository.save(new GroupMembership(null, "emp_001", "grp_001", LocalDate.of(2022, 1, 15), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_001", "grp_004", LocalDate.of(2022, 1, 15), null, "IT"));

        // Bob (emp_002) - Eng
        groupMembershipRepository.save(new GroupMembership(null, "emp_002", "grp_001", LocalDate.of(2022, 3, 10), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_002", "grp_004", LocalDate.of(2022, 3, 10), null, "IT"));

        // Charlie (emp_003) - Marketing
        groupMembershipRepository.save(new GroupMembership(null, "emp_003", "grp_002", LocalDate.of(2023, 2, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_003", "grp_004", LocalDate.of(2023, 2, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_003", "grp_006", LocalDate.of(2023, 2, 1), null, "IT"));

        // Diana (emp_004) - Marketing
        groupMembershipRepository.save(new GroupMembership(null, "emp_004", "grp_002", LocalDate.of(2023, 5, 20), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_004", "grp_004", LocalDate.of(2023, 5, 20), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_004", "grp_006", LocalDate.of(2023, 5, 20), null, "IT"));

        // Eve (emp_005) - HR
        groupMembershipRepository.save(new GroupMembership(null, "emp_005", "grp_003", LocalDate.of(2021, 8, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_005", "grp_004", LocalDate.of(2021, 8, 1), null, "IT"));

        // Frank (mgr_001) - Eng Manager
        groupMembershipRepository.save(new GroupMembership(null, "mgr_001", "grp_001", LocalDate.of(2020, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_001", "grp_004", LocalDate.of(2020, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_001", "grp_005", LocalDate.of(2020, 1, 1), null, "IT")); // Eng Leads group

        // Grace (mgr_002) - Marketing Manager
        groupMembershipRepository.save(new GroupMembership(null, "mgr_002", "grp_002", LocalDate.of(2021, 6, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_002", "grp_004", LocalDate.of(2021, 6, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_002", "grp_006", LocalDate.of(2021, 6, 1), null, "IT"));

        // Henry (mgr_003) - HR Manager (Not explicitly added, but can be inferred)
        groupMembershipRepository.save(new GroupMembership(null, "mgr_003", "grp_003", LocalDate.of(2019, 10, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_003", "grp_004", LocalDate.of(2019, 10, 1), null, "IT"));

        // Ivy (exec001) - CEO
        groupMembershipRepository.save(new GroupMembership(null, "exec_001", "grp_004", LocalDate.of(2018, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "exec_001", "grp_007", LocalDate.of(2018, 1, 1), null, "IT")); // Finance Reporting for CEO

        // Simulate some access changes for policy drift
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_001", "grp_001", "ASSIGN", LocalDateTime.of(2022, 1, 15, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_001", "grp_001", "REVOKE", LocalDateTime.of(2024, 1, 15, 9, 0), "IT", "Role change"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_001", "grp_005", "ASSIGN", LocalDateTime.of(2024, 1, 15, 9, 0), "IT", "Promoted to lead"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_002", "grp_001", "ASSIGN", LocalDateTime.of(2022, 3, 10, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_003", "grp_002", "ASSIGN", LocalDateTime.of(2023, 2, 1, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_004", "grp_002", "ASSIGN", LocalDateTime.of(2023, 5, 20, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_005", "grp_003", "ASSIGN", LocalDateTime.of(2021, 8, 1, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "mgr_001", "grp_005", "ASSIGN", LocalDateTime.of(2020, 1, 1, 9, 0), "IT", "Manager role"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "mgr_002", "grp_006", "ASSIGN", LocalDateTime.of(2021, 6, 1, 9, 0), "IT", "Manager role"));
    }
}
