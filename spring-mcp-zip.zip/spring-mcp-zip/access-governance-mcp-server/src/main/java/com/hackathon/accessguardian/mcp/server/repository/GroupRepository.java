package com.hackathon.accessguardian.mcp.server.repository;

import com.hackathon.accessguardian.mcp.server.domain.Groupee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GroupRepository extends JpaRepository<Groupee, String> {
    Optional<Groupee> findByGroupName(String groupName);
    List<Groupee> findByResourceType(String resourceType);
    Optional<Groupee> findByGroupId(String groupId);
}
