package com.hackathon.accessguardian.mcp.server.service.dataingestion;

import com.hackathon.accessguardian.mcp.server.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@EnableScheduling
@Service
@RequiredArgsConstructor
@Slf4j
public class DataIngestionScheduler {

    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final GroupMembershipRepository groupMembershipRepository;
    private final AccessChangeLogRepository accessChangeLogRepository;
    private final AccessAnomalyRepository accessAnomalyRepository;
    private final DataLoadingServiceViaCSV dataLoadingServiceViaCSV;



    // --- Scheduled Tasks for Data Ingestion ---

    @Scheduled(cron = "0 */5 * * * ?") // Example with default value
    public void loadData() {
        log.info("Scheduled task: Fetching employee data from external API.");
        // Step 1: Load all data from CSV files
        try {
            dataLoadingServiceViaCSV.loadAllData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Step 2: Run a simple test to verify the data
        log.info("----------- VERIFICATION -----------");
        log.info("Total Employees: {}", employeeRepository.count());
        log.info("Total Groups: {}", groupRepository.count());
        log.info("Total Memberships: {}", groupMembershipRepository.count());

        employeeRepository.findAll().forEach(e -> log.info("Found Employee: {}", e));
        log.info("------------------------------------");
    }
}