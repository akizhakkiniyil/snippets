package com.hackathon.accessguardian.mcp.server.repository;

import com.hackathon.accessguardian.mcp.server.domain.AccessAnomaly;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AccessAnomalyRepository extends JpaRepository<AccessAnomaly, Long> {
    List<AccessAnomaly> findByUserGuid(String userGuid);
    List<AccessAnomaly> findByDetectedDateBetween(LocalDateTime startDate, LocalDateTime endDate);
    List<AccessAnomaly> findByStatus(String status);
}